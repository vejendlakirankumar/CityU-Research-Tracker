#!/usr/bin/env bash
# =============================================================================
# install-remote.sh — Remote Docker deployment from your local machine
# =============================================================================
# Usage:
#   bash install-remote.sh [OPTIONS]
#
# Options:
#   --domain  DOMAIN   Public domain name  (required)
#   --email   EMAIL    Let's Encrypt contact email (required unless --skip-ssl)
#   --skip-ssl         Pass --skip-ssl to the remote installer
#
# Required environment variables (or edit the defaults below):
#   VM_HOST  — VM public IP or hostname    (e.g. 172.206.114.248)
#   VM_USER  — SSH username                (e.g. azureadmin)
#   VM_PASS  — SSH password  (optional if SSH_KEY is set)
#   SSH_KEY  — Path to private key         (e.g. ~/.ssh/id_rsa)
#
# Example:
#   VM_HOST=172.206.114.248 VM_USER=azureadmin VM_PASS=MyPass \
#     bash install-remote.sh --domain portal.cityu.edu --email admin@cityu.edu
# =============================================================================
set -euo pipefail

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'
info()  { echo -e "${GREEN}[INFO]${NC}  $*"; }
warn()  { echo -e "${YELLOW}[WARN]${NC}  $*"; }
error() { echo -e "${RED}[ERROR]${NC} $*" >&2; exit 1; }

# ---------- defaults ----------------------------------------------------------
VM_HOST="${VM_HOST:-}"
VM_USER="${VM_USER:-azureadmin}"
VM_PASS="${VM_PASS:-}"
SSH_KEY="${SSH_KEY:-}"
DOMAIN=""
EMAIL=""
SKIP_SSL_FLAG=""
REMOTE_DIR="/opt/rrp-v2"
APP_SCHEME="https"

# ---------- parse arguments ---------------------------------------------------
while [[ $# -gt 0 ]]; do
  case "$1" in
    --domain)   DOMAIN="$2"; shift 2 ;;
    --email)    EMAIL="$2";  shift 2 ;;
    --skip-ssl) SKIP_SSL_FLAG="--skip-ssl"; shift ;;
    *) error "Unknown argument: $1" ;;
  esac
done

[[ -z "$VM_HOST" ]] && error "VM_HOST environment variable is required"
[[ -z "$DOMAIN" ]]  && error "--domain is required"
if [[ -z "$SKIP_SSL_FLAG" && -z "$EMAIL" ]]; then
  error "--email is required unless --skip-ssl is provided"
fi

command -v ssh &>/dev/null   || error "ssh is required on the local machine"
command -v rsync &>/dev/null || error "rsync is required on the local machine"

if [[ -n "$SKIP_SSL_FLAG" ]]; then
  APP_SCHEME="http"
fi

# Determine the v2/ directory (sibling of deploy/)
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
V2_DIR="$(dirname "$SCRIPT_DIR")"

# ---------- build SSH / SCP commands -----------------------------------------
SSH_OPTS=(-o StrictHostKeyChecking=no -o ConnectTimeout=15)
if [[ -n "$SSH_KEY" ]]; then
  SSH_OPTS+=(-i "$SSH_KEY")
fi

if [[ -n "$VM_PASS" ]]; then
  # use sshpass if available; otherwise fall back to prompting
  if command -v sshpass &>/dev/null; then
    SSH_CMD=(sshpass -p "$VM_PASS" ssh "${SSH_OPTS[@]}")
    SCP_CMD=(sshpass -p "$VM_PASS" scp "${SSH_OPTS[@]}")
    RSYNC_CMD=(sshpass -p "$VM_PASS" rsync -az --progress \
      -e "ssh ${SSH_OPTS[*]}")
  else
    warn "sshpass not found — you will be prompted for the SSH password."
    SSH_CMD=(ssh "${SSH_OPTS[@]}")
    SCP_CMD=(scp "${SSH_OPTS[@]}")
    RSYNC_CMD=(rsync -az --progress -e "ssh ${SSH_OPTS[*]}")
  fi
else
  SSH_CMD=(ssh "${SSH_OPTS[@]}")
  SCP_CMD=(scp "${SSH_OPTS[@]}")
  RSYNC_CMD=(rsync -az --progress -e "ssh ${SSH_OPTS[*]}")
fi

TARGET="$VM_USER@$VM_HOST"

# ---------- 1. Install Docker on the VM if missing ---------------------------
info "Ensuring Docker is installed on $VM_HOST..."
"${SSH_CMD[@]}" "$TARGET" bash <<'REMOTE_DOCKER'
set -e
if ! command -v docker &>/dev/null; then
  curl -fsSL https://get.docker.com | sudo sh
  sudo usermod -aG docker "$USER"
fi
if ! docker compose version &>/dev/null 2>&1; then
  COMPOSE_VER="$(curl -s https://api.github.com/repos/docker/compose/releases/latest \
    | grep tag_name | cut -d'"' -f4)"
  sudo curl -SL \
    "https://github.com/docker/compose/releases/download/${COMPOSE_VER}/docker-compose-linux-x86_64" \
    -o /usr/local/lib/docker/cli-plugins/docker-compose
  sudo chmod +x /usr/local/lib/docker/cli-plugins/docker-compose
fi
echo "Docker $(docker --version)"
echo "Compose $(docker compose version)"
REMOTE_DOCKER

# ---------- 2. Copy the v2 directory to the VM -------------------------------
info "Copying v2 source to $VM_HOST:$REMOTE_DIR ..."
"${SSH_CMD[@]}" "$TARGET" "sudo mkdir -p $REMOTE_DIR && sudo chown $VM_USER:$VM_USER $REMOTE_DIR"

"${RSYNC_CMD[@]}" \
  --exclude='.git' \
  --exclude='node_modules' \
  --exclude='vendor' \
  --exclude='frontend/dist' \
  --exclude='.env' \
  "$V2_DIR/" "$TARGET:$REMOTE_DIR/"

# ---------- 3. Run install.sh on the VM (Docker mode: delegate to docker compose) --
info "Running Docker Compose deployment on the VM..."
"${SSH_CMD[@]}" "$TARGET" bash <<REMOTE_INSTALL
set -euo pipefail
cd $REMOTE_DIR

DOCKER="docker"
if ! docker info >/dev/null 2>&1; then
  DOCKER="sudo docker"
fi

# Write root-level .env (consumed by Docker Compose for variable substitution)
if [[ ! -f .env ]]; then
  echo "--- Generating .env with fresh credentials ---"
  APP_KEY=\$(openssl rand -base64 32)
  DB_PASS=\$(openssl rand -hex 24)
  REDIS_PASS=\$(openssl rand -hex 16)
  cat > .env <<ENVEOF
# Generated by install-remote.sh on \$(date -u +"%Y-%m-%d %H:%M UTC")
APP_KEY=base64:\$APP_KEY
APP_URL=$APP_SCHEME://$DOMAIN
DB_DATABASE=rrp_production
DB_USERNAME=rrp_app
DB_PASSWORD=\$DB_PASS
REDIS_PASSWORD=\$REDIS_PASS
SESSION_DOMAIN=$DOMAIN
SANCTUM_STATEFUL_DOMAINS=$DOMAIN
LOG_CHANNEL=stderr
LOG_LEVEL=error
FILESYSTEM_DISK=local
MAIL_MAILER=log
MAIL_FROM_ADDRESS=noreply@$DOMAIN
MAIL_FROM_NAME="Research Review Portal"
ENVEOF
  echo "--- .env written to $REMOTE_DIR/.env ---"
else
  echo "--- .env already exists — skipping credential generation ---"
fi

echo "--- Starting Docker Compose stack ---"
\$DOCKER compose up -d --build

# Wait for the app container to be healthy (max 3 minutes)
echo "--- Waiting for application to become healthy ---"
ATTEMPTS=0
until docker inspect --format='{{.State.Health.Status}}' rrp_app 2>/dev/null | grep -q "healthy"; do
  ATTEMPTS=\$((ATTEMPTS + 1))
  if [[ \$ATTEMPTS -ge 36 ]]; then
    echo "ERROR: Timed out waiting for rrp_app to be healthy. Recent logs:"
    \$DOCKER compose logs --tail=30 app
    exit 1
  fi
  echo -n "."
  sleep 5
done
echo " Ready!"

\$DOCKER exec -w /var/www/html rrp_app php artisan migrate --force
\$DOCKER exec -w /var/www/html rrp_app php artisan db:seed --force
\$DOCKER exec -w /var/www/html rrp_app php artisan storage:link || true
\$DOCKER exec -w /var/www/html rrp_app php artisan config:cache
\$DOCKER exec -w /var/www/html rrp_app php artisan route:cache

echo "--- Docker Compose running ---"
\$DOCKER compose ps
REMOTE_INSTALL

# ---------- 4. SSL setup on the VM -------------------------------------------
if [[ -z "$SKIP_SSL_FLAG" ]]; then
  info "Setting up SSL on the VM..."
  "${SSH_CMD[@]}" "$TARGET" \
    "sudo bash $REMOTE_DIR/deploy/ssl-setup.sh '$DOMAIN' '$EMAIL'" \
    || warn "SSL setup failed — run 'sudo bash $REMOTE_DIR/deploy/ssl-setup.sh $DOMAIN $EMAIL' manually once DNS is live."
fi

# ---------- Done --------------------------------------------------------------
info "============================================================"
info " Remote deployment complete!"
info " VM        : $VM_HOST"
info " Domain    : $DOMAIN"
info " Portal    : $APP_SCHEME://$DOMAIN"
info " Health    : $APP_SCHEME://$DOMAIN/api/system/public"
info ""
info " Default admin : admin@cityu.edu / admin12345"
info " CHANGE THIS PASSWORD IMMEDIATELY."
info "============================================================"
